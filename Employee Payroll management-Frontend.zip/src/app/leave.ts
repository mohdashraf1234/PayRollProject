export interface Leave {
  //id: number;
  employeeId: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  reason: string;
}